"""Cross-border CTA multi-strategy portfolio system."""

__all__ = ["run_pipeline"]

from .pipeline import run_pipeline
