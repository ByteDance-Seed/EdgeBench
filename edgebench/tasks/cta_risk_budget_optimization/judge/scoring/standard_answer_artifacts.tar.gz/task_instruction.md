## 题目

跨境CTA多策略组合与风险预算优化

## 任务要求

我是一家量化对冲基金（明德基金）的CTA策略团队负责人。基金管理规模15亿元人民币，投资范围覆盖境内外商品期货市场。基金目前需要从零构建一套完整的CTA多策略组合系统，包括因子构建、信号生成、仓位计算、动态风险预算分配、回撤控制、以及完整的回测框架。你需要为我完成以下任务：基于提供的原始数据和研究资料，独立完成整个系统的设计、实现和验证。
背景：明德跨境商品期货CTA基金成立于2019年，投资范围涵盖SHFE、DCE、CZCE、INE、CME、ICE、LME等境内外主要商品期货交易所的标准化期货合约。基金采用系统化量化交易方法，通过多策略、多品种、多周期的组合分散风险，同时运用动态风险预算机制在不同市场环境下自适应调整仓位与策略权重。现有单一趋势跟踪策略在2022-2023年的震荡市中表现不佳，最大回撤一度达到18%，超过基金合同约定的15%上限。投资决策委员会决定对策略体系进行全面升级。
任务目标：构建一套完整的CTA多策略组合系统，包含五个子策略（时间序列动量、截面动量、Carry/Basis、波动率突破、均值回归），实现动态风险预算分配和分级回撤控制，并通过完整的回测框架验证系统有效性。
约束条件：所有策略设计和仓位计算必须严格遵守《风险管理政策与合规约束手册》中的各项约束条件，包括组合层面（年化波动率8%-15%、最大回撤≤15%、VaR≤3%等）、品种层面（单一品种≤10%、板块≤30%等）、策略层面（单一策略风险预算≤40%等）约束。回测必须使用真实的交易成本参数，境外品种盈亏必须使用汇率折算为人民币。
输入数据：提供5个输入文件——futures_price_data.xlsx（30个品种的日线OHLCV及期限结构数据）、futures_contract_specs.xlsx（合约规格、保证金、交易成本、持仓限额）、macro_factors_data.xlsx（中美宏观指标、全球指标、汇率数据）、risk_policy_doc.docx（风控政策与合规约束手册）、strategy_research_notes.docx（6份内部策略研究备忘录）。
交付物：完整策略系统代码（Python项目）、信号矩阵、回测结果（每日净值、持仓明细、交易记录）、绩效评估报告、压力测试报告、敏感性分析报告、风险预算分配表。

## 任务输入说明

请使用以下输入文件，均位于 `attachments/` 目录下：

- `attachments/题目Prompt-跨境CTA多策略组合与风险预算优化.docx`：题目 Prompt
- `attachments/futures_price_data.xlsx`：境内外商品期货品种的日线 OHLCV 数据（2020-2025 年）及期限结构数据，含 3 个工作表：`domestic_futures`、`overseas_futures`、`carry_basis_data`
- `attachments/futures_contract_specs.xlsx`：合约规格、保证金率历史、交易日历、交易成本、持仓限额，含 5 个工作表
- `attachments/macro_factors_data.xlsx`：中国/美国宏观经济指标月度数据、全球指标日线数据、汇率日线数据，含 4 个工作表
- `attachments/risk_policy_doc.docx`：基金风险管理政策与合规约束手册，包含 7 章内容：基金概况、风险限额体系、回撤控制、动态风险预算、跨境风险管控、压力测试、合规报告
- `attachments/strategy_research_notes.docx`：内部策略研究备忘录，涵盖 TSMOM 参数优化、Carry 策略方案、截面动量、波动率突破、均值回归、多策略组合与风险预算分配
- `attachments/requirements.txt`

## 交付物要求

- . | Python project directory
- signal_matrix.csv | CSV
- backtest_results | directory containing daily NAV, position details, and trade records
- performance_report.md | Markdown
- stress_test_report.md | Markdown
- sensitivity_analysis_report.md | Markdown
- risk_budget_allocation.csv | CSV
